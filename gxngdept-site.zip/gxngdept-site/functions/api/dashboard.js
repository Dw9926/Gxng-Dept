// Cloudflare Pages Function — GET /api/dashboard
//
// Owner-only read endpoint. Requires the DASH_KEY secret (set it in the
// Pages project settings — see SETUP.md) sent back as either the
// x-dash-key header or a ?key= query param. Returns aggregate counters,
// the signup list, and a slice of recent raw events for dashboard.html
// to render.

export async function onRequestGet(context) {
  const { request, env } = context;

  if (!env.GXNG_KV) {
    return json({ error: 'kv_not_bound' }, 500);
  }
  if (!env.DASH_KEY) {
    return json({ error: 'dash_key_not_set' }, 500);
  }

  const url = new URL(request.url);
  const suppliedKey = request.headers.get('x-dash-key') || url.searchParams.get('key') || '';
  if (suppliedKey !== env.DASH_KEY) {
    return json({ error: 'unauthorized' }, 401);
  }

  const counterKeys = await listAll(env.GXNG_KV, 'ctr_');
  const counters = {};
  for (const k of counterKeys) {
    const v = await env.GXNG_KV.get(k.name);
    counters[k.name.slice('ctr_'.length)] = parseInt(v, 10) || 0;
  }

  const signupKeys = await listAll(env.GXNG_KV, 'signup_', 1000);
  const signups = [];
  for (const k of signupKeys) {
    const v = await env.GXNG_KV.get(k.name);
    if (v) {
      try { signups.push(JSON.parse(v)); } catch (err) { /* skip malformed */ }
    }
  }
  signups.sort((a, b) => b.ts - a.ts);

  const eventKeys = await listAll(env.GXNG_KV, 'evt_', 2000);
  const recentKeys = eventKeys.slice(-80);
  const events = [];
  for (const k of recentKeys) {
    const v = await env.GXNG_KV.get(k.name);
    if (v) {
      try { events.push(JSON.parse(v)); } catch (err) { /* skip malformed */ }
    }
  }
  events.sort((a, b) => b.ts - a.ts);

  return json({
    counters,
    signups: signups.slice(0, 200),
    events: events.slice(0, 80),
    totalEventsSeen: eventKeys.length,
  });
}

async function listAll(kv, prefix, cap = 5000) {
  let out = [];
  let cursor;
  do {
    const res = await kv.list({ prefix, cursor, limit: 1000 });
    out = out.concat(res.keys);
    cursor = res.cursor;
    if (out.length >= cap) break;
    if (res.list_complete) break;
  } while (cursor);
  return out;
}

function json(data, status) {
  return new Response(JSON.stringify(data), {
    status: status || 200,
    headers: { 'content-type': 'application/json' },
  });
}

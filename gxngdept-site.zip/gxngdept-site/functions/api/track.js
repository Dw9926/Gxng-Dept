// Cloudflare Pages Function — POST /api/track
//
// Logs one visitor-interest event to the GXNG_KV namespace (bind it in
// the Pages project settings — see SETUP.md). Every event is stored as
// its own key (auto-expires after 180 days) and a small set of running
// counters is bumped alongside it so the dashboard can render fast
// without re-scanning the whole event log.
//
// Accepted event types: page_view, product_view, product_click,
// cta_click, signup. Anything else is rejected — this endpoint is
// intentionally narrow, not a general-purpose logger.

const ALLOWED_TYPES = new Set([
  'page_view',
  'product_view',
  'product_click',
  'cta_click',
  'signup',
]);

export async function onRequestPost(context) {
  const { request, env } = context;

  if (!env.GXNG_KV) {
    return new Response('KV not bound', { status: 500 });
  }

  let body;
  try {
    body = await request.json();
  } catch (err) {
    return new Response('Bad JSON', { status: 400 });
  }

  const type = String(body.type || '');
  if (!ALLOWED_TYPES.has(type)) {
    return new Response('Unknown event type', { status: 400 });
  }

  const now = Date.now();
  const visitorId = String(body.visitorId || 'anon').slice(0, 64);
  const path = String(body.path || '').slice(0, 200);
  const ref = String(body.ref || '').slice(0, 200);
  const meta = sanitizeMeta(body.meta);

  const timeKey = String(now).padStart(13, '0');
  const rand = Math.random().toString(36).slice(2, 8);

  const event = { ts: now, type, visitorId, path, ref, meta };

  const ninetyDays = 60 * 60 * 24 * 180;
  await env.GXNG_KV.put(`evt_${timeKey}_${rand}`, JSON.stringify(event), {
    expirationTtl: ninetyDays,
  });

  await bump(env, `ctr_${type}`);
  if (type === 'page_view' && meta.src) await bump(env, `ctr_pageview_src_${meta.src}`);
  if (type === 'product_view' && meta.id) await bump(env, `ctr_view_${meta.id}`);
  if (type === 'product_click' && meta.id) await bump(env, `ctr_click_${meta.id}`);
  if (type === 'cta_click' && meta.id) await bump(env, `ctr_cta_${meta.id}`);

  if (type === 'signup' && meta.email) {
    const signup = { ts: now, email: String(meta.email).slice(0, 200), source: meta.source || '' };
    await env.GXNG_KV.put(`signup_${timeKey}_${rand}`, JSON.stringify(signup));
  }

  return new Response(null, { status: 204 });
}

// A GET here just confirms the endpoint is wired up — handy for
// checking your deploy without opening the browser console.
export async function onRequestGet(context) {
  const bound = Boolean(context.env.GXNG_KV);
  return new Response(JSON.stringify({ ok: true, kvBound: bound }), {
    headers: { 'content-type': 'application/json' },
  });
}

function sanitizeMeta(meta) {
  const out = {};
  if (!meta || typeof meta !== 'object') return out;
  const keys = Object.keys(meta).slice(0, 10);
  for (const k of keys) {
    const v = meta[k];
    if (typeof v === 'string') out[k.slice(0, 40)] = v.slice(0, 200);
    else if (typeof v === 'number' || typeof v === 'boolean') out[k.slice(0, 40)] = v;
  }
  return out;
}

async function bump(env, key) {
  // Best-effort increment. Not atomic — under heavy concurrent traffic
  // two writes could race and undercount by one. Fine at boutique-drop
  // scale; if this ever needs to be exact at high volume, move counters
  // to a Durable Object.
  const current = await env.GXNG_KV.get(key);
  const n = current ? parseInt(current, 10) || 0 : 0;
  await env.GXNG_KV.put(key, String(n + 1));
}
